/* null version of <netdb.h> - <sys/socket.h> has everything */

