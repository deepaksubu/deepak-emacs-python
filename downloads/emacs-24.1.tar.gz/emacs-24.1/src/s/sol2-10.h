/* Handle Solaris 2.10.  */

#include "sol2-6.h"

/* This is used in list_system_processes.  */
#define HAVE_PROCFS 1

/* This is needed for the system_process_attributes implementation.  */
#define _STRUCTURED_PROC 1

